# RMI example - client

This is a Hello World example of a Java RMI client application
with a code security manager to use an external RMI registry.

The client depends on the interface module, 
where the interface shared between server and client is defined.
The client needs to know the interface to generate the proxy.


## Instructions for using Maven



Make sure that you installed the interface module first.

To compile and copy the properties file to the output directory:

```
mvn compile
```


To generate launch scripts for Windows and Linux:
(appassembler:assemble is attached to install phase)

```
mvn install
```


To run the RMI client:

Using Maven exec plugin:

```
mvn exec:java
```

Using Maven appassembler plugin:

On Windows:

```
target\appassembler\bin\hello-rmi-client.bat
```

On Linux:

```
./target/appassembler/bin/hello-rmi-client
```


## To configure the Maven project in Eclipse

'File', 'Import...', 'Maven'-'Existing Maven Projects'

'Select root directory' and 'Browse' to the project base folder.

Check that the desired POM is selected and 'Finish'.


----

[SD Faculty](mailto:leic-sod@disciplinas.tecnico.ulisboa.pt)
