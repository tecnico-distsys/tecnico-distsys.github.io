# Tic Tae Toe Web Service

This is a distributed game of Tic Tac Toe implemented using Java Web Services.
The server is published to a jUDDI registry and
the client uses the name server to find the actual server location.

The server is a Web Service.
It stores the game state and provides operations for modifying it.


## Instructions for using Maven

To compile:

```
mvn compile
```

To run using exec plugin:

```
mvn exec:java
```

When running, the web service awaits connections from clients.
You can check if the service is running using your web browser 
to see the [generated WSDL file](http://localhost:8080/ttt-ws/endpoint?WSDL).
   
This address is defined when the publish() method is called.

To call the service you will need a web service client,
including code generated from the WSDL.


## To configure the Maven project in Eclipse

'File', 'Import...', 'Maven'-'Existing Maven Projects'

'Select root directory' and 'Browse' to the project base folder.

Check that the desired POM is selected and 'Finish'.


----

[SD Faculty](mailto:leic-sod@disciplinas.tecnico.ulisboa.pt)
