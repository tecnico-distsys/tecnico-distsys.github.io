package ttt;

public class Game {

    public static void main(String[] args) throws Exception {
    	  /* TO DO */
    }

}
