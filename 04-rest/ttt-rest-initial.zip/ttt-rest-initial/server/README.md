# Rest API TTT - server

This is a Rest API implementation of Tic Tac Toe.

## Instructions for using Maven

To install and run the server:

```
mvn install exec:java
```


## To configure the Maven project in Eclipse

'File', 'Import...', 'Maven'-'Existing Maven Projects'

'Select root directory' and 'Browse' to the project base folder.

Check that the desired POM is selected and 'Finish'.


----

[SD Faculty](mailto:leic-sod@disciplinas.tecnico.ulisboa.pt)
