package com.ecar.domain;

public class ECarManager {

	// Singleton -------------------------------------------------------------

	private ECarManager() {
	}

	/**
	 * SingletonHolder is loaded on the first execution of Singleton.getInstance()
	 * or the first access to SingletonHolder.INSTANCE, not before.
	 */
	private static class SingletonHolder {
		private static final ECarManager INSTANCE = new ECarManager();
	}

	public static synchronized ECarManager getInstance() {
		return SingletonHolder.INSTANCE;
	}

	
	// TODO

}
