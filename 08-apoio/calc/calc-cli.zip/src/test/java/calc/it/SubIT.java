package calc.it;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * Integration Test suite
 */
public class SubIT extends BaseCalcIT {

	// tests
	// assertEquals(expected, actual);

	// public int sum(int a, int b)

	@Test
	public void test() throws Exception {
		final int result = client.sub(24, 2);
		assertEquals(22, result);
	}

	// ...

}
