package com.ecar.ws.cli;

public class ECarClientApp {

    public static void main(String[] args) throws Exception {
        // Check arguments
        if (args.length == 0) {
            System.err.println("Argument(s) missing!");
            System.err.println("Usage: java " + ECarClientApp.class.getName()
                    + " wsURL OR uddiURL wsName");
            return;
        }
        String uddiURL = null;
        String wsName = null;
        String wsURL = null;
        if (args.length == 1) {
            wsURL = args[0];
        } else if (args.length >= 2) {
            uddiURL = args[0];
            wsName = args[1];
        }

		System.out.println();
		System.out.println(ECarClientApp.class.getSimpleName() + " running");
		System.out.println();

		for (int index = 0; index < args.length; ++index) {
            System.out.println("args[" + index + "]: " + args[index]);
        }
		
        // Create client
		
		// TODO

	}
}

