package example.grpc.client;

import example.grpc.HelloWorld;
import example.grpc.HelloWorldServiceGrpc;
import example.grpc.HelloWorldServiceGrpc.HelloWorldServiceBlockingStub;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import pt.ulisboa.tecnico.sdis.zk.ZKNaming;
import pt.ulisboa.tecnico.sdis.zk.ZKRecord;


public class HelloClient {

	public static void main(String[] args){
		System.out.println(HelloClient.class.getSimpleName());

		// receive and print arguments
		System.out.printf("Received %d arguments%n", args.length);
		for (int i = 0; i < args.length; i++) {
			System.out.printf("arg[%d] = %s%n", i, args[i]);
		}

		if (args.length != 2) {
		      System.out.println("Usage: PATH zk://ADDR:PORT");
		      return;
		}
		
		String path = new String(args[0]);
		String zkAddress = new String(args[1]);
		
		ZKNaming zkNaming = null;
		ManagedChannel channel = null;
		HelloWorldServiceBlockingStub stub = null;
		ZKRecord record = null;
		try {
			
			zkNaming = new ZKNaming(zkAddress);
			// Lookup
			System.out.printf("lookup on zookeeper address: %s%n",zkAddress);
			record = zkNaming.lookup(path);

			System.out.printf("found record: %s%n",record.getURI());
			// Channel is the abstraction to connect to a service endpoint
			// Let us use plaintext communication because we do not have certificates
			channel = ManagedChannelBuilder.forTarget(record.getURI()).usePlaintext().build();
			
			
			// It is up to the client to determine whether to block the call
			// Here we create a blocking stub, but an async stub,
			// or an async stub with Future are always possible.
			stub = HelloWorldServiceGrpc.newBlockingStub(channel);
			HelloWorld.HelloRequest request = HelloWorld.HelloRequest.newBuilder().setName("friend").build();
			
			// Finally, make the call using the stub
			HelloWorld.HelloResponse response = stub.greeting(request);

			// HelloResponse has auto-generated toString method that shows its contents
			System.out.println(response);

			// A Channel should be shutdown before stopping the process.
			channel.shutdown();
	
		}catch (Exception e) {
			System.out.printf("Caught exception: %s%n", e);
			e.printStackTrace();
		}
	}
}
	
