package example.thread;


public class Main {

    public static void main(String[] args) {

        try {
            System.out.printf(Main.class + " starting...");

            // create arguments for thread
            Object argument = new Integer(22);

            // create thread object
            MyThread myThread = new MyThread(argument);
            // set it as a daemon so the JVM doesn't wait for it when quitting
            myThread.setDaemon(true);

            // acquire lock on myThread object (the argument object could also be used as synchronization token)
            synchronized(myThread) {

                // start thread
                myThread.start();

                try {
                    // release lock, wait for thread or for timeout
                    myThread.wait(5*1000);
                    // after wait, the lock is reacquired

                    Exception exception = myThread.getException();
                    Object result = myThread.getResult();

                    if(exception != null) {
                        System.out.println(Main.class + " received exception " + exception + " from thread");
                    }

                    if(result != null) {
                        System.out.println(Main.class + " received result " + result + " from thread");
                    }

                }
                catch (InterruptedException e) {
                    // thread was interrupted
                    throw e;
                }
            }

        } catch (Exception e) {
            // print error information
            System.out.println(Main.class + " caught exception in main method: " + e);
        }

        System.out.println(Main.class + " finished.");
    }

}
