package example;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class Server {

	public static void main(String args[]) throws Exception {
		System.out.println("Creating object and exporting it...");
		HelloImpl obj = new HelloImpl();
		Hello servant = (Hello) UnicastRemoteObject.exportObject(obj, 0);

		System.out.println("Binding the remote object's servant in the registry...");
		Registry registry = LocateRegistry.getRegistry();
		registry.rebind("hello", servant);

		System.out.println("Server ready!");

		System.out.println("Awaiting connections");
		System.out.println("Press enter to shutdown");
		System.in.read();
		System.exit(0);
	}

}
