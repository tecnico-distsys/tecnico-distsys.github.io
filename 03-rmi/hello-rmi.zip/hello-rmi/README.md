# Hello RMI

This is a Hello World example of a Java RMI application
with a code security manager to use an external RMI registry.

It is composed of three modules:

 - [interface](interface/) - defines the remove interface of the service
 - [server](server/) - implementation of the service
 - [client](client/) - client that remotely invokes the service

See the README.md for each module.
Start by looking at the interface, then go to server, and finally go to the client.

----

[SD Faculty](mailto:leic-sod@disciplinas.tecnico.ulisboa.pt)
