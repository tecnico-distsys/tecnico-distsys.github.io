package pt.ulisboa.tecnico.sdis.cert;

import java.io.File;

public class BaseTest {

	public BaseTest() {
		super();
	}

}
