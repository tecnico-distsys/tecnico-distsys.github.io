package org.ECar.ws.it;

import org.junit.Test;


/**
 * Test suite
 */
public class PingIT extends BaseIT {

    // tests
    // assertEquals(expected, actual);

    // public String ping(String x)

    @Test
    public void pingEmptyTest() {
		// assertNotNull(ECarClient.testPing("test"));
    }

}
