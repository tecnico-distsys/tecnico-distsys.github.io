This is a Hello World example of a Java RMI application
with a code security manager to use an external RMI registry.


Instructions using Maven:
------------------------

To compile:
  mvn compile

To generate launch scripts for Windows and Linux and
(appassembler:assemble is attached to install phase)
make the project library available for the client:
  mvn install

To run:
  First change to the class folder (target/classes) and
  start the rmiregistry:
    On Windows
      cd target\classes
      start rmiregistry
    On Linux
      cd target/classes
      rmiregistry &

An alternative is to start the RMI Registry with the required code base:
  (replace project directory as necessary)
  (if the path is wrong no warning is produced immediately)
  On Windows:
    rmiregistry -J-Djava.rmi.server.codebase=file:target/hello-rmi-server-1.0-SNAPSHOT.jar
  On Linux
    rmiregistry -J-Djava.rmi.server.codebase=file:target/hello-rmi-server-1.0-SNAPSHOT.jar &

Finally, start the server:
  Using Maven exec plugin:
    mvn exec:java
  Using Maven appassembler plugin:
    On Windows:
      target\appassembler\bin\ttt-rmi-server_secman
    On Linux:
      ./target/appassembler/bin/ttt-rmi-server_secman


To configure the Maven project in Eclipse:
-----------------------------------------

'File', 'Import...', 'Maven'-'Existing Maven Projects'
'Select root directory' and 'Browse' to the project base folder.
Check that the desired POM is selected and 'Finish'.


--
Revision date: 2017-03-10
leic-sod@disciplinas.tecnico.ulisboa.pt
