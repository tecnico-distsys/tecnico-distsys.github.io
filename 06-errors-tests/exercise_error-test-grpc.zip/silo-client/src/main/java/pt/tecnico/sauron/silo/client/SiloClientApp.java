package pt.tecnico.sauron.silo.client;

import pt.tecnico.sauron.silo.grpc.Silo.PingRequest;
import pt.tecnico.sauron.silo.grpc.Silo.PingResponse;

import java.util.Scanner;

public class SiloClientApp {
  private static final String EXIT_CMD = "exit";

  public static void main(String[] args) {
    System.out.println(SiloClientApp.class.getSimpleName());

    // receive and print arguments
    System.out.printf("Received %d arguments%n", args.length);
    for (int i = 0; i < args.length; i++) {
      System.out.printf("arg[%d] = %s%n", i, args[i]);
    }

    // check arguments
    if (args.length < 2) {
      System.out.println("Argument(s) missing!");
      System.out.printf("Usage: java %s host port%n", SiloClientApp.class.getName());
      return;
    }

    final String host = args[0];
    final int port = Integer.parseInt(args[1]);

    try (SiloFrontend siloFrontend = new SiloFrontend(host, port);
        Scanner scanner = new Scanner(System.in)) {
      while (true) {
        System.out.print("> Enter a message to send to the server (`exit` to quit)\n> ");
        String message = scanner.nextLine();

        if (EXIT_CMD.equals(message)) break;
        PingResponse response =
            siloFrontend.ctrlPing(PingRequest.newBuilder().setMessage(message).build());
        System.out.println("[+] The server replied with '" + response.getMessage() + "'");

        // TODO Catch and handle the StatusRuntimeException here, after invoking ctrlPing.
      }

    } finally {
      System.out.println("> Closing");
    }
  }
}
