package calc;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


/**
 *  Unit Test suite
 *  The purpose of this class is to test CalcPort locally.
 */
public class CalcPortImplTest {

    // members

    private CalcPortImpl localPort;


    // initialization and clean-up for each test

    @Before
    public void setUp() {
    	localPort = new CalcPortImpl();
    }

    @After
    public void tearDown() {
        localPort = null;
    }


    // tests

	@Test
	public void testSum() throws Exception {
		final int result = localPort.sum(2, 1);
		assertEquals(3, result);
	}

	@Test
	public void testSub() throws Exception {
		final int result = localPort.sub(2, 1);
		assertEquals(1, result);
	}

	// ...

}
