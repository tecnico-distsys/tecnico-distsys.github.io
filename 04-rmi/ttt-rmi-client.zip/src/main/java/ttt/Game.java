package ttt;

/** This is the client of the Tic Tac Toe game. */
public class Game {

	/** The program starts running in the main method. */
	public static void main(String[] args) throws Exception {
		/* TO-DO */
	}

}
