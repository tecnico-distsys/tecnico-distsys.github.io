This is a Hello World example of a Java RMI application
with a code security manager to use an external RMI registry.

The server depends on the interface module, 
where the interface shared between server and client is defined.
The server needs to know the interface to provide an implementation for it.

Instructions using Maven:
------------------------

Make sure that you installed the interface module first.

To compile:
  mvn compile

To also generate launch scripts for Windows and Linux
(appassembler:assemble is attached to install phase):
  mvn install

To run:
  First change to the interface class folder (target/classes) and
  start the rmiregistry there:
    On Windows
      cd hello-rmi-interface
      cd target\classes
      start rmiregistry
    On Linux
      cd hello-rmi-interface
      cd target/classes
      rmiregistry &

An alternative is to start the RMI Registry with the required code base:
  (replace project directory as necessary)
  (if the path is wrong no warning is produced immediately)
  On Windows:
    cd hello-rmi-interface
    rmiregistry -J-Djava.rmi.server.codebase=file:target/hello-rmi-interface-1.0-SNAPSHOT.jar
  On Linux
    cd hello-rmi-interface
    rmiregistry -J-Djava.rmi.server.codebase=file:target/hello-rmi-interface-1.0-SNAPSHOT.jar &

Finally, start the RMI server:
  Using Maven exec plugin:
    mvn exec:java
  Using Maven appassembler plugin:
    On Windows:
      target\appassembler\bin\hello-rmi-server
    On Linux:
      ./target/appassembler/bin/hello-rmi-server


To configure the Maven project in Eclipse:
-----------------------------------------

'File', 'Import...', 'Maven'-'Existing Maven Projects'
'Select root directory' and 'Browse' to the project base folder.
Check that the desired POM is selected and 'Finish'.


--
Revision date: 2018-03-03
leic-sod@disciplinas.tecnico.ulisboa.pt
