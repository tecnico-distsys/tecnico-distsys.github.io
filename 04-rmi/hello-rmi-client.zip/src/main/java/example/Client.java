package example;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Client {

	public static void main(String[] args) throws Exception {

		String host = (args.length < 1) ? null : args[0];
		final String NAME = "Hello";
		
		System.out.println("Looking up " + NAME + "...");
		Registry registry = LocateRegistry.getRegistry(host);
		Hello stub = (Hello) registry.lookup(NAME);

		System.out.println(stub.getClass().getName());
		
		System.out.println("Invoking remote method...");
		String response = stub.sayHello();

		System.out.println("Response: " + response);
	}

}
