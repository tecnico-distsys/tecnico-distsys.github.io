package example;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Client {

	public static void main(String[] args) throws Exception {

		String host = (args.length < 1) ? null : args[0];
		final String NAME = "hello";
		
		System.out.println("Looking up using name " + NAME + "...");
		Registry registry = LocateRegistry.getRegistry(host);
		Hello proxy = (Hello) registry.lookup(NAME);

		System.out.print("Proxy class name: ");
		System.out.println(proxy.getClass().getName());
		
		System.out.println("Invoking remote method...");
		String response = proxy.sayHello();
		System.out.println("Response: " + response);
	}

}
