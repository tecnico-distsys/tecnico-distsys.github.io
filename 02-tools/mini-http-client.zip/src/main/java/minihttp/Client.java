package minihttp;

import java.net.*;
import java.io.*;

public class Client {

    public static void main(String[] args) throws IOException {
        // Check arguments
        if (args.length < 3) {
            System.err.println("Argument(s) missing!");
            System.err.printf("Usage: java %s host port file%n", Client.class.getName());
            return;
        }

        String host = args[0];
        int port = Integer.parseInt(args[1]);
        File file = new File(args[2]);

        System.out.println("Arguments:");
        System.out.println("Host: " + host);
        System.out.println("Port: " + port);
        System.out.println("File: " + file + " (length: " + file.length() + " bytes)");


        //
        // Mini-HTTP Request
        //

        // Create client socket
        Socket socket = new Socket(host, port);
        System.out.printf("Connected to server %s on port %d %n", host, port);

        // Create stream to send data to server
        DataOutputStream out = new DataOutputStream(socket.getOutputStream());

        out.write("POST /Endpoint MiniHTTP/0.1\n".getBytes());
        out.write("Host: localhost\n".getBytes());
        out.write("Content-Length: ".getBytes());
        out.write(Long.toString(file.length()).getBytes());
        out.write("\n".getBytes());
        out.write("\n".getBytes());

        // Read file
        byte[] fileContents = getBytesFromFile(file);
        // Send file contents
        out.write(fileContents);

        //
        // Await server response
        //

        // Create stream to read data from server
        InputStream socketInputStream = socket.getInputStream();
        Reader socketReader = new InputStreamReader(socketInputStream);
        BufferedReader socketLineReader = new BufferedReader(socketReader);

        String response;

        // Receber dados do cliente
        response = socketLineReader.readLine();
        if(response.equals("MiniHTTP/0.1 200 OK"))
            System.out.println("OK");
        else
        //if(resposta.equals("MiniHTTP/0.1 500 Server Error"))
            System.out.println("Error");

        // read separator
        response = socketLineReader.readLine();

        // Close client socket
        socket.close();
        System.out.println("Connection closed");
    }


    // Returns the contents of the file in a byte array.
    public static byte[] getBytesFromFile(File file) throws IOException {

        // Create byte array in memory to hold the data
        long length = file.length();
        byte[] buffer = new byte[(int)length];

        // Read in the bytes
        InputStream is = new FileInputStream(file);

        int offset = 0;
        int numRead = 0;
        while (offset < buffer.length
               && (numRead=is.read(buffer, offset, buffer.length-offset)) >= 0) {
            offset += numRead;
        }

        // Ensure all the bytes have been read in
        if (offset < buffer.length) {
            throw new IOException("Could not completely read file " + file);
        }

        // Close the input stream and return bytes
        is.close();
        return buffer;
    }

}
