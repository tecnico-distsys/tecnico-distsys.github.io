package calc;

import javax.jws.WebService;

@WebService(
	name = "Calc", 
	targetNamespace = "urn:calc", 
	wsdlLocation = "Calc.wsdl", 
	serviceName = "CalcService",
	portName = "CalcPort", 
	endpointInterface = "calc.CalcPortType" 
)
public class CalcPortImpl implements CalcPortType {

	// endpoint
	private CalcEndpointManager endpoint;

	public CalcPortImpl(CalcEndpointManager endpoint) {
		this.endpoint = endpoint;
	}

	CalcPortImpl() {
	}
	
	// CalcPortType implementation

	public int sum(int a, int b) {
		return a + b;
	}

	public int sub(int a, int b) {
		return a - b;
	}

	public int mult(int a, int b) {
		return a * b;
	}

	public int intdiv(int a, int b) throws DivideByZero {
		if (b == 0)
			throw new DivideByZero(endpoint.getWsName() + " cannot divide by zero!", new DivideByZeroType());
		return a / b;
	}

}
