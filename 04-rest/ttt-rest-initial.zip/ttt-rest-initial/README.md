# Rest API TTT

This is a Rest API implementation of Tic Tac Toe, composed by two modules:
- [server](server/) - implementation of service
- [client](client/) - invocation of service

See the README for each module.
Start at the server and then go to the client.

----

[SD Faculty](mailto:leic-sod@disciplinas.tecnico.ulisboa.pt)
