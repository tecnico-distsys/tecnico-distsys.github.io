package pt.tecnico.sauron.silo;

import io.grpc.stub.StreamObserver;
import pt.tecnico.sauron.silo.domain.Silo;
import pt.tecnico.sauron.silo.grpc.Silo.PingRequest;
import pt.tecnico.sauron.silo.grpc.Silo.PingResponse;
import pt.tecnico.sauron.silo.grpc.SiloServiceGrpc.SiloServiceImplBase;

import java.util.logging.Logger;

public final class SiloServiceImpl extends SiloServiceImplBase {
  private static final Logger LOGGER = Logger.getLogger(SiloServiceImpl.class.getName());
  private final Silo silo = new Silo();

  @Override
  public void ctrlPing(PingRequest request, StreamObserver<PingResponse> responseObserver) {
    String message = request.getMessage();
    LOGGER.info("[+] Received ping request with message '" + message + "'");

    // Let the silo handle the message.
    String response = silo.handleCtrlPing(message);
    LOGGER.info("[+] Sending '" + response + "' back to the client");

    /*
    TODO Map the thrown domain exceptions to error status codes here.
      Recall that both onCompleted() and onError() change the execution flow of the program.
       */

    responseObserver.onNext(PingResponse.newBuilder().setMessage(response).build());
    // We must always complete the call, otherwise an exception is thrown.
    responseObserver.onCompleted();
  }
}
