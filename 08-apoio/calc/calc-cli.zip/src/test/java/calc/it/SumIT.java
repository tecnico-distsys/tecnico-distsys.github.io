package calc.it;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * Integration Test suite
 */
public class SumIT extends BaseCalcIT {

	// tests
	// assertEquals(expected, actual);

	// public int sum(int a, int b)

	@Test
	public void testPositive() throws Exception {
		final int result = client.sum(1, 2);
		assertEquals(3, result);
	}

	@Test
	public void testNegative() throws Exception {
		final int result = client.sum(-1, -2);
		assertEquals(-3, result);
	}

	@Test
	public void testPositiveNegative() throws Exception {
		final int result = client.sum(1, -2);
		assertEquals(-1, result);
	}

	@Test
	public void testZero() throws Exception {
		final int result = client.sum(0, 0);
		assertEquals(0, result);
	}

	// ...

}
