package example.grpc.server;

import io.grpc.BindableService;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import pt.ulisboa.tecnico.sdis.zk.ZKNaming;






public class HelloServer {

	
	public static void main(String[] args) {
			
		System.out.println(HelloServer.class.getSimpleName());
	
		// receive and print arguments
		System.out.printf("Received %d arguments%n", args.length);
		for (int i = 0; i < args.length; i++) {
			System.out.printf("arg[%d] = %s%n", i, args[i]);
		}
	
		// check arguments
		if (args.length != 4) {
      System.out.println("Usage: zk://ADDR:PORT host port path");
      return;
		}
		
		
		String zkAddr = new String(args[0]);
		String host= new String(args[1]);
		String port = new String(args[2]);
		String path = new String(args[3]);
		
		Server server = null;
		BindableService impl = null;
		ZKNaming zkNaming = null;
		try {
		
			zkNaming = new ZKNaming(zkAddr);
	
			// publish
			zkNaming.rebind(path,host,port);
	
			impl = new HelloWorldServiceImpl();
	
			// Create a new server to listen on port
			server = ServerBuilder.forPort(Integer.parseInt(port)).addService(impl).build();  
		  
	
		  server.start();
		  // Server threads are running in the background.
			System.out.println("Server started");
	
			// wait
			System.out.println("Awaiting connections");
			System.out.println("Press enter to shutdown");
			System.in.read();
					
		}catch (Exception e) {
			System.out.printf("Caught exception: %s%n", e);
				
		}finally{
			try{
				if (zkNaming != null) {
					// remove
					zkNaming.unbind(path,host,port);
				}
			} catch (Exception e) {
				System.out.printf("Caught exception when deleting: %s%n", e);
			}
			
			try {
				if (server != null) {
					server.shutdown();
				}
				
			} catch (Exception e) {
				System.out.printf("Caught exception when shuting down: %s%n", e);
			}
		}
	}
}
