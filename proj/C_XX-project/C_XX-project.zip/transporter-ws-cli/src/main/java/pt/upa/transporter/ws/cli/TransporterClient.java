package pt.upa.transporter.ws.cli;

public class TransporterClient {

	// TODO

}
