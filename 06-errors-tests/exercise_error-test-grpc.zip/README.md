# gRPC error handling and JUnit tests exercise

This is the starting point for exercise on error handling and JUnit tests with gRPC.


The project is composed by three modules:
- [silo-contract](silo-contract/) - protocol buffers definition
- [silo-server](silo-server/) - implementation of service
- [silo-client](silo-client/) - invocation of service

See the README for each module.  
Start at contract, then go to server, and finally go to the client.

----

For help, please contact:

[SD Faculty](mailto:leic-sod@disciplinas.tecnico.ulisboa.pt)
