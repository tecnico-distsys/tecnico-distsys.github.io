package example.ws;

public class EchoException extends Exception {

    private static final long serialVersionUID = 1L;

    public EchoException(String string) {
        super(string);
    }

}
