This is a simple REST Service

The service runs in a standalone HTTP server, started by the Main class.

The resource is defined by the MyResource class and mapped to HTTP through annotations specified by JAX-RS (Java API for RESTful Web Services).

The service is defined by the Java code with annotations
(code-first approach, also called bottom-up approach).


Instructions using Maven:
------------------------

To compile:
  mvn compile

To run using exec plugin:
  mvn exec:java

When running, the REST service awaits connections from clients.
You can check if the service is running using your web browser 
to see the generated WADL file, go to:
    http://localhost:8080/myapp/application.wadl
for a more detailed version add a parameter:
    http://localhost:8080/myapp/application.wadl?detail=true

To call the service, retrieve (GET) the following URL:
    http://localhost:8080/myapp/myresource


To configure the Maven project in Eclipse:
-----------------------------------------

'File', 'Import...', 'Maven'-'Existing Maven Projects'
'Select root directory' and 'Browse' to the project base folder.
Check that the desired POM is selected and 'Finish'.


--
Revision date: 2020-03-02
leic-sod@disciplinas.tecnico.ulisboa.pt
