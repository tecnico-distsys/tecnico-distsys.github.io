package pt.upa.transporter.ws;

public class TransporterPort {

	// TODO

}
