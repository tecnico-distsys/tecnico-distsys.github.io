package pt.tecnico.sauron.silo.client;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import pt.tecnico.sauron.silo.grpc.Silo.PingRequest;
import pt.tecnico.sauron.silo.grpc.SiloServiceGrpc;
import pt.tecnico.sauron.silo.grpc.SiloServiceGrpc.SiloServiceBlockingStub;

import java.io.IOException;
import java.util.Properties;

public class BaseIT {
  private static final String TEST_PROP_FILE = "/test.properties";
  protected static Properties properties;
  static SiloServiceBlockingStub silo;

  /*
  TODO Extend this class by creating a new one named CtrlPingIT.
   */

  @BeforeAll
  public static void oneTimeSetup() throws IOException {
    properties = new Properties();

    try {
      properties.load(BaseIT.class.getResourceAsStream(TEST_PROP_FILE));
      System.out.println("Test properties:");
      System.out.println(properties);
    } catch (IOException e) {
      final String msg = String.format("Could not load properties file %s", TEST_PROP_FILE);
      System.out.println(msg);
      throw e;
    }

    final String siloName = properties.getProperty("server.host");
    final int siloPort = Integer.parseInt(properties.getProperty("server.port"));
    ManagedChannel channel =
        ManagedChannelBuilder.forAddress(siloName, siloPort).usePlaintext().build();
    silo = SiloServiceGrpc.newBlockingStub(channel);
  }

  @AfterAll
  public static void cleanup() {}
}
