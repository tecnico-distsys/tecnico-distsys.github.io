package minihttp;

import java.net.*;
import java.io.*;

public class Server {

  public static void main(String[] args) throws Exception {
    // Check arguments
    if (args.length < 1) {
        System.err.println("Argument(s) missing!");
        System.err.printf("Usage: java %s port%n", Server.class.getName());
        return;
    }

    int port = Integer.parseInt(args[0]);


    //
    // Create socket and await connections
    //

    // Create server socket
    ServerSocket serverSocket = new ServerSocket(port);
    System.out.printf("MiniHTTP Server accepting connections on port %d %n", port);

    // wait for and then accept client connection
    // a socket is created to handle the created connection
    Socket clientSocket = serverSocket.accept();
    System.out.printf("Connected to client %s on port %d %n",
        clientSocket.getInetAddress().getHostAddress(), clientSocket.getPort());

    //
    // Communication with client
    //

    // Create stream to receive data from client
    InputStream socketInputStream = clientSocket.getInputStream();
    Reader socketReader = new InputStreamReader(socketInputStream);
    BufferedReader socketLineReader = new BufferedReader(socketReader);

    //
    // Process Mini-HTTP headers
    //
    String request;

    request = socketLineReader.readLine();
    if(!(request.equals("POST /Endpoint MiniHTTP/0.1")))
    	cleanExit(clientSocket, serverSocket);

    request = socketLineReader.readLine();
    if(!(request.equals("Host: localhost")))
    	cleanExit(clientSocket, serverSocket);

    request = socketLineReader.readLine();
    if(!request.startsWith("Content-Length: "))
    	cleanExit(clientSocket, serverSocket);

    String sizeString = request.substring(16);
    int size = Integer.parseInt(sizeString);
    System.out.println("Size: " + size);

    request = socketLineReader.readLine();
    if(!request.startsWith(""))
       	cleanExit(clientSocket, serverSocket);

    //
    // Process Mini-HTTP body
    //
    byte[] body = new byte[size];

    // read until all expected bytes are received
    int byteCount = 0;
    while(byteCount < size) {
        int result = socketInputStream.read(body, byteCount, size-byteCount);
        if(result == -1) {
            System.out.println("Error while reading data from socket!");
            cleanExit(clientSocket, serverSocket);
        }
        byteCount += result;
    }
    System.out.printf("Received body with %d bytes%n", byteCount);

    //
    // save body as file
    //

    File tempFile = File.createTempFile("MiniHTTP_", "", new File("./target"));
    FileOutputStream fos = new FileOutputStream(tempFile);
    fos.write(body);
    fos.close();
    System.out.printf("Saved body to file: %s%n", tempFile.getCanonicalPath());


    //
    // Return answer to client
    //

    // Create stream to send data to client
    OutputStream socketOutputStream = clientSocket.getOutputStream();
    DataOutputStream socketDataOutputStream = new DataOutputStream(socketOutputStream);

    socketDataOutputStream.writeBytes("MiniHTTP/0.1 200 OK\n");
    // socketDataOutputStream.writeBytes("MiniHTTP/0.1 500 Server Error\n");

    cleanExit(clientSocket, serverSocket);
  }

  private static void cleanExit(Socket clientSocket, ServerSocket serverSocket) throws IOException {
	try {
        // Close connection to current client
        if (clientSocket != null) {
            clientSocket.close();
            System.out.println("Closed connection with client");
        }

        // Close server socket
        if (serverSocket != null) {
            serverSocket.close();
            System.out.println("Closed server socket");
        }

        // shutdown virtual machine
		System.exit(0);

	} catch (IOException e)	{
		System.err.printf("Caught exception: %s%n", e);
		// rethrow
		throw e;
	}
  }

}
