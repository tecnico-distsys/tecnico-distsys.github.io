package pt.tecnico.sauron.silo.client;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import pt.tecnico.sauron.silo.grpc.Silo.PingRequest;
import pt.tecnico.sauron.silo.grpc.Silo.PingResponse;
import pt.tecnico.sauron.silo.grpc.SiloServiceGrpc.SiloServiceBlockingStub;

import static pt.tecnico.sauron.silo.grpc.SiloServiceGrpc.newBlockingStub;

public class SiloFrontend implements AutoCloseable {
  private final ManagedChannel channel;
  private final SiloServiceBlockingStub silo;

  protected SiloFrontend(String host, int port) {
    // Channel is the abstraction to connect to a service endpoint.
    // Let us use plaintext communication because we do not have certificates.
    this.channel = ManagedChannelBuilder.forAddress(host, port).usePlaintext().build();

    // It is up to the client to determine whether to block the call.
    // Here we create a blocking stub, but an async stub, or an async stub with
    // Future are also available.
    silo = newBlockingStub(channel);
  }

  public PingResponse ctrlPing(PingRequest pingRequest) {
    return silo.ctrlPing(pingRequest);
  }

  @Override
  public final void close() {
    channel.shutdown();
  }
}
