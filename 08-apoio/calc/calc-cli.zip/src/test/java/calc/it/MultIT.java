package calc.it;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * Integration Test suite
 */
public class MultIT extends BaseCalcIT {

	// tests
	// assertEquals(expected, actual);

	// public int sum(int a, int b)

	@Test
	public void test() throws Exception {
		final int result = client.mult(7, 8);
		assertEquals(56, result);
	}

	// ...

}
