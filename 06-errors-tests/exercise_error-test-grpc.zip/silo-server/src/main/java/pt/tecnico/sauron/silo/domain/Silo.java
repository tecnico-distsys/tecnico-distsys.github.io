package pt.tecnico.sauron.silo.domain;

public class Silo {
  public String handleCtrlPing(String message) {
    // TODO Validate the received message here.
    return message;
  }
}
