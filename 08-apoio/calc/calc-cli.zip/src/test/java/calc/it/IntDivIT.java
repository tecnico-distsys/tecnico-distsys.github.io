package calc.it;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import calc.DivideByZero;

/**
 * Integration Test suite
 */
public class IntDivIT extends BaseCalcIT {

	// tests
	// assertEquals(expected, actual);

	// public int intdiv(int a, int b) throws DivideByZero

	@Test(expected = DivideByZero.class)
	public void testDivideByZero() throws Exception {
		client.intdiv(13, 0);
		// JUnit expects the exception declared in the annotation
	}

	@Test
	public void testExact() throws Exception {
		final int result = client.intdiv(10, 5);
		assertEquals(2, result);
	}

	@Test
	public void testRound() throws Exception {
		final int result = client.intdiv(10, 4);
		assertEquals(2, result);
	}

	@Test
	public void testExactNegative() throws Exception {
		final int result = client.intdiv(-10, -5);
		assertEquals(2, result);
	}

	@Test
	public void testRoundNegative() throws Exception {
		final int result = client.intdiv(-10, -4);
		assertEquals(2, result);
	}

	// ...

}
