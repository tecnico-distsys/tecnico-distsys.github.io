package com.ecar.ws;

public class ECarApp {

	public static void main(String[] args) throws Exception {

		System.out.println();
		System.out.println(ECarApp.class.getSimpleName() + " running");
		System.out.println();

		for (int index = 0; index < args.length; ++index) {
            System.out.println("args[" + index + "]: " + args[index]);
        }
		
		// TODO
	}

}