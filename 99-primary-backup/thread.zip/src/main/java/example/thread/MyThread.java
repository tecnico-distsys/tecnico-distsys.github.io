package example.thread;


public class MyThread extends Thread {

    Object result;
    Exception exception;
    Object argument;

    public MyThread(Object argument) {
        this.argument = argument;
    }

    public Object getResult() {
        synchronized(this) {
            return this.result;
        }
    }

    public Exception getException() {
        synchronized(this) {
            return this.exception;
        }
    }

    public void run() {
        try {
            System.out.println(this.getClass() + " running...");

            // read argument (any object)
            Integer arg = (Integer) this.argument;

            // Do something...
            // (in this example, sleep)
            sleep(10*1000);

            // return result (any object)
            this.result = new Integer(arg + 1);

            // Acquire lock and notify waiting thread
            synchronized(this) {
                this.notifyAll();
            }

        } catch (Exception e) {
            System.out.println(this.getClass() + " caught exception: " + e.toString());
            this.exception = e;

        } finally {
            System.out.println(this.getClass() + " stopping.");
        }
    }

}
