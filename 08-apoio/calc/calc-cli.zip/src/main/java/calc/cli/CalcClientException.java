package calc.cli;

/**
 * This exception is used by the CalcClient to throw exceptions with 
 * more meaningful error messages.
 */
public class CalcClientException extends Exception {

	private static final long serialVersionUID = 1L;

	public CalcClientException() {
	}

	public CalcClientException(String message) {
		super(message);
	}

	public CalcClientException(Throwable cause) {
		super(cause);
	}

	public CalcClientException(String message, Throwable cause) {
		super(message, cause);
	}

}
