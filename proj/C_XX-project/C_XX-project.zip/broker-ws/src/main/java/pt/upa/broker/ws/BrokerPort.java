package pt.upa.broker.ws;

public class BrokerPort {

	// TODO

}
