# ForkExec

**Fork**: delicious menus for **Exec**utives

Distributed Systems 2018-2019, 2nd semester project

## Part 2 continuation code

This is a solution for the implementation of the Points server and its test client.

This code can be used to replace an incomplete implementation, and serve as a starting point for the second part of the project.
We recommend that you keep your current implementation and only use this one if you failed to complete the points service in the first part of the project.

Also, be careful not to overwrite your parent POM file in the main project folder with the one included here.

### Code identification

In all the source files (including POMs), please replace __CXX__ with your Campus: A (Alameda) or T (Tagus); and your group number with two digits.

This is important for code dependency management 
i.e. making sure that your code runs using the correct components and not someone else's.


### Prerequisites

Java Developer Kit 8 is required running on Linux, Windows or Mac.
Maven 3 is also required.

To confirm that you have them installed, open a terminal and type:

```
javac -version

mvn -version
```
