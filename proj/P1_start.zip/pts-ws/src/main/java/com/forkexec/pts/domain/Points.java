package com.forkexec.pts.domain;

import com.forkexec.pts.domain.exception.EmailAlreadyExistsFaultException;
import com.forkexec.pts.domain.exception.InvalidEmailFaultException;
import com.forkexec.pts.domain.exception.InvalidPointsFaultException;
import com.forkexec.pts.domain.exception.NotEnoughBalanceFaultException;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Pattern;

/**
 * Points
 * <p>
 * A points server.
 */
public class Points {

    /**
     * Constant representing the default initial balance for every new client
     */
    private static final int DEFAULT_INITIAL_BALANCE = 100;
    /**
     * Global counter of rentals. Uses lock-free thread-safe single variable. This
     * means that multiple threads can update this variable concurrently with
     * correct synchronization.
     */
    private final AtomicInteger totalGets = new AtomicInteger(0);
    /**
     * Global counter of returns. Uses lock-free thread-safe single variable.
     */
    private final AtomicInteger totalReturns = new AtomicInteger(0);
    /**
     * Global with current number of free docks. Uses lock-free thread-safe single
     * variable.
     */
    private final AtomicInteger freeDocks = new AtomicInteger(0);
    /**
     * Accounts.
     */
    private Map<String, AtomicInteger> accounts;
    /**
     * Global with the current value for the initial balance of every new client
     */
    private final AtomicInteger initialBalance = new AtomicInteger(DEFAULT_INITIAL_BALANCE);

    // Singleton -------------------------------------------------------------

    /**
     * Private constructor prevents instantiation from other classes.
     */
    private Points() {
        // Initialization of default values
        reset();
    }

    /**
     * SingletonHolder is loaded on the first execution of Singleton.getInstance()
     * or the first access to SingletonHolder.INSTANCE, not before.
     */
    private static class SingletonHolder {
        private static final Points INSTANCE = new Points();
    }

    public static synchronized Points getInstance() {
        return SingletonHolder.INSTANCE;
    }

    /**
     * Synchronized locks object to configure initial values
     */
    public synchronized void init() {}

    public synchronized void reset() {
        // replace hash map with a clean one
        accounts = new ConcurrentHashMap<>();
        initialBalance.set(DEFAULT_INITIAL_BALANCE);
    }

    private void checkValidEmail(final String emailAddress) throws InvalidEmailFaultException {
        final String message;
        if (emailAddress == null) {
            message = "Null email is not valid";
        }
        else if (!Pattern.matches("(\\w\\.?)*\\w+@\\w+(\\.?\\w)*", emailAddress)) {
            message = String.format("Email: %s is not valid", emailAddress);
        }
        else {
            return;
        }
        throw new InvalidEmailFaultException(message);
    }

    public void initAccount(final String accountId) throws EmailAlreadyExistsFaultException, InvalidEmailFaultException {
        checkValidEmail(accountId);
        if (accounts.containsKey(accountId)) {
            final String message = String.format("Account with email: %s already exists", accountId);
            throw new EmailAlreadyExistsFaultException(message);
        }
        AtomicInteger points = accounts.get(accountId);
        if (points == null) {
            points = new AtomicInteger(initialBalance.get()); // Initial balance = 100
            accounts.put(accountId, points);
        }
    }

    private synchronized AtomicInteger getPoints(final String accountId) throws InvalidEmailFaultException {
        final AtomicInteger points = accounts.get(accountId);
        if (points == null)
            throw new InvalidEmailFaultException("Account does not exist!");
        return points;
    }

    public void addPoints(final String accountId, final int value)
            throws InvalidPointsFaultException, InvalidEmailFaultException {
        checkValidEmail(accountId);
        final AtomicInteger points = getPoints(accountId);
        if (value < 0){
            throw new InvalidPointsFaultException("Value cannot be negative!");
        }
        switch(value){
            case 10:
                points.addAndGet(1000);
                accounts.replace(accountId, points);
                break;
            case 20:
                points.addAndGet(2100);
                accounts.replace(accountId, points);
                break;
            case 30:
                points.addAndGet(3300);
                accounts.replace(accountId, points);
                break;
            case 50:
                points.addAndGet(5500);
                accounts.replace(accountId, points);
                break;
            default:
                final String message = String.format("Value: %d not allowed", value);
                throw new InvalidPointsFaultException(message);
        }
    }

    public int getAccountPoints (final String accountId) throws InvalidEmailFaultException {
        checkValidEmail(accountId);
        return getPoints(accountId).get();
    }

    public synchronized void removePoints(final String accountId, final int pointsToSpend)
            throws InvalidEmailFaultException, NotEnoughBalanceFaultException, InvalidPointsFaultException {
        checkValidEmail(accountId);
        final AtomicInteger points = getPoints(accountId);
        if (pointsToSpend < 0){
            throw new InvalidPointsFaultException("Value cannot be negative!");
        }
        if (points.addAndGet(-pointsToSpend) < 0){
            points.addAndGet(pointsToSpend);
            throw new NotEnoughBalanceFaultException();
        }
    }

    public void setInitialBalance(int newBalance) {
        initialBalance.set(newBalance);
    }
}
