package org.komparator.supplier.ws.cli;

public class SupplierClientApp {

	public static void main(String[] args) throws Exception {
		// Check arguments
		if (args.length == 0) {
			System.err.println("Argument(s) missing!");
			System.err.println("Usage: java " + SupplierClientApp.class.getName() + " wsURL");
			return;
		}
		String wsURL = null;
        wsURL = args[0];

		// Create client
		SupplierClient client = null;
        System.out.printf("Creating client for server at %s%n", wsURL);
        client = new SupplierClient(wsURL);

		// the following remote invocations are just basic examples
		// the actual tests are made using JUnit

		System.out.println("Invoke ping()...");
		String result = client.ping("eval client");
		System.out.print("Result: ");
		System.out.println(result);
	}

}
