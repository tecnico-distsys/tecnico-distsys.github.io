package example;

import java.rmi.RemoteException;

public class HelloImpl implements Hello {

	@Override
	public String sayHello() throws RemoteException {
		System.out.println("Responding to remote method invocation");
		return "Hello world!";
	}

}
